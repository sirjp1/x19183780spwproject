<?php
// Error Reporting Turn On
ini_set('error_reporting', 0);

// Setting up the time zone
date_default_timezone_set('Europe/Dublin');

// Host Name
$dbhost = 'localhost';

// Database Name
$dbname = 'timeinby_ecomdb';

// Database Username
$dbuser = 'timeinby_ecomdb';

// Database Password
$dbpass = 'projectwork';

// Defining base url
define("BASE_URL", "http://x19183780.spwproject.xyz/");

// Getting Admin url
define("ADMIN_URL", BASE_URL . "admin" . "/");

try {
	$pdo = new PDO("mysql:host={$dbhost};dbname={$dbname}", $dbuser, $dbpass);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch( PDOException $exception ) {
	echo "Connection error :" . $exception->getMessage();
}