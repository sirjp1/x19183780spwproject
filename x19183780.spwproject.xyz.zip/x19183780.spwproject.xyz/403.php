<?php 
?>

You are not permitted to access this resource.